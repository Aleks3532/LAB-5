
package guiuserapp.Database;

import java.security.Key;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;



public class Encryptor 
{
    private static final String ALGO = "AES";
    private static final byte[] Hiddenkey = new byte[] { 'T', 'H', 'E', 'G', 'L', 'O', 'R','D', 'G', 'S', 'A','R', 'U', 'M', 'A', 'N' };//I know...
    
    private Encryptor(){};
    
    public static String Encrypt(String Data) throws Exception 
    {
        Key key = generateKey();
        Cipher c = Cipher.getInstance(ALGO);
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] encVal = c.doFinal(Data.getBytes());   
        
        return Base64.getEncoder().withoutPadding().encodeToString(encVal);
    }
    
    
    public static String Decrypt(String Data) throws Exception 
    {
        Key key = generateKey();
        Cipher c = Cipher.getInstance(ALGO);
        c.init(Cipher.DECRYPT_MODE, key);
        byte[] decordedValue = Base64.getMimeDecoder().decode(Data);
        byte[] decValue = c.doFinal(decordedValue);
        String decryptedValue = new String(decValue);

        return decryptedValue;
    }
    
    
    private static Key generateKey() throws Exception 
    {
        Key key = new SecretKeySpec(Encryptor.Hiddenkey, ALGO);
        return key;
    }
}
