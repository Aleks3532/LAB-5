
package guiuserapp.Database;

import guiuserapp.User.UserData;
import javafx.collections.ObservableList;

public interface IDatabase 
{
   
    void addData(UserData data) throws Exception;
    
    
    void editData(UserData oldData, UserData newData) throws Exception;
    
    
    void removeData(UserData data) throws Exception;
    
    
    void restoreContent() throws Exception;
    
    
    ObservableList<UserData> getContents();
}
