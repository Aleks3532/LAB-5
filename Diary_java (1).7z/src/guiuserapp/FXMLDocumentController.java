
package guiuserapp;

import guiuserapp.Database.IDatabase;
import guiuserapp.Database.userDataDatabase;
import guiuserapp.User.UserData;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;


public class FXMLDocumentController implements Initializable
{
    private final IDatabase database;
    
    @FXML
    private TextField name;
    @FXML
    private ListView<UserData> nameList;
    @FXML
    private TextArea text;
    @FXML
    private Text System_print;
    @FXML
    private Button Save_button;
    
    private UserData safe;

    public FXMLDocumentController()
    {
        database = new userDataDatabase();
    }
    
    @FXML
    private void handleSave_button()
    {
        UserData data = new UserData(name.getText(), text.getText());
        try
        {
            database.editData(safe, data);
             clear();
             Save_button.setVisible(false);
        }
        catch(Exception e)
        {
            System_print.setText(e.getMessage());
        }
    }
    
    @FXML
    private void handleClick_event()
    { 
        UserData data = nameList.getSelectionModel().getSelectedItem();
        if(data != null)
        {
            safe = data;
            setText(data);
            Save_button.setVisible(true);
        }
    }

    @FXML
    private void handleAdd_button()
    {
        try
        {
            database.addData(new UserData(name.getText(), text.getText()));
        }
        catch(Exception e)
        {
            System_print.setText(e.getMessage());
        }
    }

    @FXML
    private void handleRemove_button()
    {
        UserData  data = (UserData)nameList.getSelectionModel().getSelectedItem();
        try
        {
            database.removeData(data);
        }
        catch(Exception e)
        {
            System_print.setText(e.getMessage());
        }
        clear();
        Save_button.setVisible(false);
    }

    @FXML
    private void handleUndo_button()
    {
        try
        {
            database.restoreContent();
        }
        catch(Exception e)
        {
            System_print.setText(e.getMessage());
        }
    }

    
    private void clear()
    {
        text.clear();
        name.clear();
        System_print.setText("");
    }
    
    private void setText(UserData data)
    {
        name.setText(data.getName());
        text.setText(data.getText());
    }

    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        
        nameList.setItems(database.getContents());
        Save_button.setVisible(false);
    }
}