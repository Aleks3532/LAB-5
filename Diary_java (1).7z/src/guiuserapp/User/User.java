
package guiuserapp.User;

public class User
{
    private String nick;
    private static User instance = null;
    
    private User(){}
    
    private User(String nick)
    { 
        this.nick = nick; 
    }
    
    public static User getInstance()
    {
        if(instance == null)
            instance = new User();
        
            return instance;
    }
    
    public void setData(String nick)
    {
        this.nick = nick; 
    }
    
    public String getName()
    {
        return this.nick;
    }
} 
