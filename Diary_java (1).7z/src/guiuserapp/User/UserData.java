
package guiuserapp.User;

public class UserData 
{
    private String DataName;
    private String text;
    
   public UserData(String DataName, String text)
   {
       this.DataName = DataName.toLowerCase();
       this.text     = text;
   }
   
   
   public String getText()
   {
       return text;
   }
   
   
   public String getName()
   {
       return DataName;
   }
   
   
   public void setDatas(String DataName, String text)
   {
       this.DataName = DataName.toLowerCase();
       this.text     = text;
   }
   
   public void setName(String DataName)
   {
       this.DataName = DataName;
   }
   
   public void setText(String text)
   {
       this.text = text;
   }
   
   @Override
    public String toString()
    {
        return DataName;
    }
}