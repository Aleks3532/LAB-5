
package guiuserapp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class Diary extends Application
{   
    public static Stage stage;
    
    @Override
    public void start(Stage stage) throws Exception 
    {
        //Parent root = FXMLLoader.load(getClass().getResource("/services/login.fxml"));
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        
        stage.setScene(scene);
        stage.setTitle("Diary");
        stage.show();
        
        Diary.stage = stage;
    }

    
    public static void main(String[] args) 
    {
        launch(args);
    }
}
