
package services;

import guiuserapp.Diary;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.image.Image;
import javafx.stage.Stage;


public class RegisterController extends LoginController
{
    @FXML
    private PasswordField passwdFieldAgain;
    
    @FXML
    private void handleLogin_button() throws IOException
    {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("login.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle("Login");
        stage.getIcons().add(new Image("/images/icon.png"));
        stage.setScene(new Scene(root1));
        stage.show();
        
        Diary.stage.close();
        Diary.stage = stage;
    }
    
    @FXML
    private void handleRegister_button()
    {
        UserService usr = new UserService();
        try
        {
            usr.register(nickField.getText(), passwdField.getText(), passwdFieldAgain.getText());
        }
        catch(Exception ex)
        {
            errorText.setText(ex.getMessage());
        }
    }
}
