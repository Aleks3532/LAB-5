
package services;

import guiuserapp.User.User;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;


public class UserService
{
    private String userPath;
    
    UserService()
    {
        setPath();
    }
    
    
    private boolean authenticate(String nick, String passwd)
    {
        
        try(BufferedReader reader = new BufferedReader(new FileReader(userPath + "/users")))
        {
            
            String line;
            while((line = reader.readLine()) != null)
            {
                int index = line.indexOf(';');
                if(index == -1)
                    continue;
                
                if(line.substring(0, index).equals(nick))
                {
                    String pswd = line.substring(index + 1);
                    
                    MessageDigest engine = MessageDigest.getInstance("SHA-256");
                	String sha = new String(engine.digest(passwd.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
                    if(pswd.equals(sha))
                        return true;
                }
            }
        }
        catch(Exception ex)
        {
            System.err.println(ex.getMessage());
        }
        
        return false;
    }
    
    
    public boolean login(String nick, String passwd)
    {
        if(authenticate(nick, passwd))
        {
            User user = User.getInstance();
            user.setData(nick);
            return true;
        }
        else
            return false;
    }
    
   
    public void register(String nick, String passwd, String passwdAgain) throws Exception
    {
        if(nick.length() == 0 || passwd.length() == 0 || passwdAgain.length() == 0)
            throw new Exception("Invalid input!");
        
        if(passwd.equals(passwdAgain))
        {
            if(exists(nick))
                throw new Exception("User already exists!");
            else
            {
            	MessageDigest engine = MessageDigest.getInstance("SHA-256");
            	String sha = new String(engine.digest(passwd.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
                createUser(nick, sha);
            }
        }
        else
            throw new Exception("Passwords does not match!");
    }
    
    
    private boolean exists(String nick)
    {
        try(BufferedReader reader = new BufferedReader(new FileReader(userPath + "/users")))
        {
            String line;
            while((line = reader.readLine()) != null)
            {
                int index = line.indexOf(';');
                if(index == -1)
                    continue;
                
                line = line.substring(0, index);
                if(line.equals(nick))
                    return true;
            }
        }
        catch(Exception ex)
        {
            System.err.println(ex.getMessage());
        }
        
        return false;
    }
    
    
    private void createUser(String nick, String passwd) throws Exception
    {
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(userPath + "/users", true)))
        {
            writer.write(nick);
            writer.write(';');
            writer.write(passwd);
            writer.newLine();
            writer.close();
        }
        catch(Exception ex)
        {
            System.err.println(ex);
            throw new Exception("Unable to save user!");
        }
    }
    
    
    private void setPath()
    {
        String OS = System.getProperty("os.name").toUpperCase();
        
        if(OS.contains("LINUX"))
            userPath = System.getProperty("user.home") + File.separator + ".torar/" + "users";
        else if(OS.contains("WIN") )
            userPath = System.getenv("APPDATA") + File.separator + "torar/" + "users";
        else
            userPath = System.getProperty("user.home") + File.separator + ".torar/" + "users";
        
        File des = new File(userPath);
        if(!des.exists())
            des.mkdirs();
    }
}